﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Startup
{
    public static void Main()
    {
        List<int> coords = Console.ReadLine()
            .Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(int.Parse)
            .ToList();

        Point topLeft = new Point(coords[0], coords[1]);
        Point bottomRight = new Point(coords[2], coords[3]);
        Rectangle rectangle = new Rectangle(topLeft, bottomRight);
        int counter = int.Parse(Console.ReadLine());
        for (int index = 0; index < counter; index++)
        {
            List<int> pointCoords = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToList();
            Point point = new Point(pointCoords[0], pointCoords[1]);
            Console.WriteLine(rectangle.ContainsPoint(point));
        }
    }
}
