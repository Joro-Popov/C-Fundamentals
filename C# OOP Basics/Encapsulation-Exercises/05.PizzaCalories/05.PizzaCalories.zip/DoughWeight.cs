﻿public enum DoughWeight
{
    MinValue = 1,
    MaxValule = 200
}