﻿public class Startup
{
    private static void Main()
    {
        Engine engine = new Engine();
        engine.Run();
    }
}