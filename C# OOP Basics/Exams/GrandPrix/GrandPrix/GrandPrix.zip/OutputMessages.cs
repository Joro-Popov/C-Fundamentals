﻿using System;
using System.Collections.Generic;
using System.Text;

public static class OutputMessages
{
    public static string BlownTyre => "Blown Tyre";
    public static string OutOfFuel => "Out of fuel";
    public static string InvalidTime => "There is no time! On lap {0}.";
    public static string Crashed => "Crashed";
}
