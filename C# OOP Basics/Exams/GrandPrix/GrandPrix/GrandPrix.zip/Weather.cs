﻿public enum Weather
{
    Sunny, Rainy, Foggy
}